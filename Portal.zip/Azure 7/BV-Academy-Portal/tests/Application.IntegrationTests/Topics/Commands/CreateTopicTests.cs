﻿using BvAcademyPortal.Application.Common.Exceptions;
using BvAcademyPortal.Application.Topics.Commands.CreateTopic;
using BvAcademyPortal.Application.Courses.Commands.CreateCourse;
using BvAcademyPortal.Domain.Entities;
using FluentAssertions;
using NUnit.Framework;
using System;
using System.Threading.Tasks;

namespace BvAcademyPortal.Application.IntegrationTests.Topics.Commands
{
    using static Testing;

    public class CreateTopicTests : TestBase
    {
        [Test]
        public void ShouldRequireMinimumFields()
        {
            var command = new CreateTopicCommand();

            FluentActions.Invoking(() =>
                SendAsync(command)).Should().Throw<ValidationException>();
        }

        [Test]
        public async Task ShouldCreateTopic()
        {
            var userId = await RunAsDefaultUserAsync();

            var listId = await SendAsync(new CreateCourseCommand
            {
                Title = "New List"
            });

            var command = new CreateTopicCommand
            {
                ListId = listId,
                Title = "Tasks"
            };

            var itemId = await SendAsync(command);

            var item = await FindAsync<Topic>(itemId);

            item.Should().NotBeNull();
            item.ListId.Should().Be(command.ListId);
            item.Title.Should().Be(command.Title);
            item.CreatedBy.Should().Be(userId);
            item.Created.Should().BeCloseTo(DateTime.Now, 10000);
            item.LastModifiedBy.Should().BeNull();
            item.LastModified.Should().BeNull();
        }
    }
}
