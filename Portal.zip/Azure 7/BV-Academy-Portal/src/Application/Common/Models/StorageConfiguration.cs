﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BvAcademyPortal.Application.Common.Models
{
    public class StorageConfiguration
    {
        public string AzureConnection { get; set; }
        public string BlobName { get; set; }
    }
}
