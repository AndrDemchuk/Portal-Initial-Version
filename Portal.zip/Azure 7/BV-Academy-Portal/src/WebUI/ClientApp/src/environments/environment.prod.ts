export const environment = {
  production: true,
  localApi: null
};
