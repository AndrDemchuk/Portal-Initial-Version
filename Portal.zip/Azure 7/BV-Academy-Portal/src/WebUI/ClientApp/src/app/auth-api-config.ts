// The current application coordinates were pre-registered in a B2C tenant.
export const apiConfig = {
  b2cScopes: ['https://academybv.onmicrosoft.com/helloapi/demo.read'],
  webApi: 'https://academybv.onmicrosoft.com/dev/user_impersonation'
};
