﻿namespace BvAcademyPortal.Domain.Enums
{
    public enum SkillLevel
    {
        None = 0,
        Low = 1,
        Medium = 2,
        High = 3,
        VeryHigh = 4
    }
}