﻿using Microsoft.AspNetCore.Identity;

namespace BvAcademyPortal.Infrastructure.Identity
{
    public class ApplicationUser : IdentityUser
    {
    }
}
